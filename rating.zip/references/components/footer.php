<footer>
    <h1>Rating Me</h1>
    <p>Somos una comunidad que está creando un nuevo producto sobre la importancia de las referencias de los clientes. El producto será una plataforma en línea que permitirá a los clientes compartir sus experiencias con las empresas con las que han interactuado. La plataforma también proporcionará a las empresas información sobre cómo mejorar sus servicios y productos en función de los comentarios de los clientes.</p>
    <p>La comunidad cree que este producto es importante porque las referencias de los clientes son una de las formas más efectivas de generar nuevos negocios. Cuando un cliente comparte una experiencia positiva con una empresa, es más probable que otros clientes también lo hagan. Esto puede conducir a un aumento de las ventas y la participación de los clientes.</p>
    <hr>
    <h1>Contacta a soporte</h1>
    <p>Si tienes alguna duda, problema o sugerencia lo puedes hacer enviando un mensaje a este correo: </p>
    <ul>
        <li><i><strong>ratingmehelp@gmail.com</strong></i></li>
    </ul>
</footer>
<script src="js/moment.js"></script>